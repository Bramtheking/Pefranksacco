package com.example.pefranksacco;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private UserCredentialDAO userCredentialDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Initialize UI elements
        View progressBar = findViewById(R.id.progressBar);
        EditText emailEditText = findViewById(R.id.emailEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton5);
        TextView here = findViewById(R.id.here);
        CheckBox rememberMeCheckbox = findViewById(R.id.checkBox3);
        userCredentialDAO = new UserCredentialDAO(this);
        userCredentialDAO.open();
        String stringBuildModel = "Model: " + Build.MODEL +
                "\nManufacturer: " + Build.MANUFACTURER +
                "\nDevice: " + Build.DEVICE+ Build.SERIAL;
        Log.d("DeviceInfo", stringBuildModel);

        // Initialize UserCredentialDAO
        UserCredential savedUserCredential = userCredentialDAO.getSavedUserCredential();
        if (savedUserCredential != null) {
            emailEditText.setText(savedUserCredential.getEmail());
            passwordEditText.setText(savedUserCredential.getPassword());
        }
        if (savedUserCredential != null) {
            // Directly go to the welcome activity
            goToWelcomeActivity();
        }
        if (!isNetworkAvailable()) {
            Toast.makeText(this, "App cannot work without internet connection", Toast.LENGTH_SHORT).show();
        }


        here.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, next.class);
                startActivity(intent);
            }
        });

        // Set a click listener for the login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the entered email and password
                if (isNetworkAvailable()) {
                    String email = emailEditText.getText().toString();
                    String password = passwordEditText.getText().toString();



                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.VISIBLE);
                    }
                  });

                // Start a background thread for network operations
                Thread backgroundThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        int SDK_INT = android.os.Build.VERSION.SDK_INT;
                        if (SDK_INT > 8) {
                            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                                    .permitAll().build();
                            StrictMode.setThreadPolicy(policy);

                            // Call the API to validate the user's credentials using the loginUserAsync method
                            ApiService.loginUserAsync(email, password, new ApiService.LoginCallback() {
                                @Override
                                public void onLoginComplete(String response) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            progressBar.setVisibility(View.GONE);
                                        }
                                    });

                                    // Check if the response indicates a successful login
                                    if (response != null && response.startsWith("{\"auth\":true,\"user\":{")) {
                                        if (rememberMeCheckbox.isChecked()) {
                                            // Insert the email and password into the SQLite database
                                            insertUserCredential(email, password);
                                        }

                                        // If the API validates the user, show a success dialog
                                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                        goToWelcomeActivity();
                                      } else {
                                        // If not valid, show an error dialog
                                        Toast.makeText(MainActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }
                    }
                 });

                // Start the background thread
                backgroundThread.start();

            }else {
                    // Display a message when there is no internet connection
                    Toast.makeText(MainActivity.this, "App cannot work without internet connection", Toast.LENGTH_SHORT).show();
                }}

        });
    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }
    private void insertUserCredential(String email, String password) {
        // Insert the user's email and password into the SQLite database
        UserCredential userCredential = new UserCredential(email, password);
        userCredentialDAO.insertUserCredential(userCredential);
    }

    private void goToWelcomeActivity() {
        Intent intent = new Intent(MainActivity.this, welcome.class);
        startActivity(intent);
        finish(); // Finish the login activity so that the user cannot go back
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userCredentialDAO.close();
    }
}
